#include "r_macro.h"  /* System macro and standard type definition */
#include "r_spi_if.h" /* SPI driver interface */
#include "lcd.h"      /* LCD driver interface */


/******************************************************************************
* Global Function Prototypes
******************************************************************************/
void LCD_reset(void);
void r_main_userinit(void);